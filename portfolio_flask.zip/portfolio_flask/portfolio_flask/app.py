from flask import Flask, render_template, jsonify

app = Flask(__name__)

# -----------------------------
# Ruta web (HTML)
# -----------------------------
@app.route("/")
def home():
    return render_template("portfolio.html")

# -----------------------------
# API REST (JSON)
# -----------------------------
@app.route("/api/profile")
def api_profile():
    data = {
        "name": "Martin Maiz Negredo",
        "karrera": "Ingeniari mekaniko eta elektronikoa",
        "github": "https://github.com/martintxo333",
        "linkedin": "https://www.linkedin.com/in/martin-maiz-negredo"
    }
    return jsonify(data)

if __name__ == "__main__":
    app.run(debug=True)
